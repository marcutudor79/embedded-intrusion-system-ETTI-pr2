#include <mega164a.h>
#include <stdio.h>
#include <stdlib.h>
#include "adc_mcu.h"
#include "alarm_mcu.h"
#include "delay.h"

void initialise_mcu(); 

/* Function that initializes the ports and the
ADC of the mcu */