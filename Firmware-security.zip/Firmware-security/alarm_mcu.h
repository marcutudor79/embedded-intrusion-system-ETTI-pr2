#include <mega164a.h>
#include "delay.h"

void ring_alarm();
    /*  Activates the piezo element on the board 
        Turns on the RED Led in order to signal a state of alarm. 
        The Blue led is turned off.
    */


